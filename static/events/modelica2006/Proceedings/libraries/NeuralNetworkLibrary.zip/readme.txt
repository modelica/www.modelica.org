NeuralNetwork Library
---------------------
+ Icons				In this folder there are some images used in the library.
+ Utilities			In this folder there is the extractData.m, which is the script used to pass the neural network parameters from the MatLab environment to the Modelica one.
- testData_RadialBasisNN.mat	It is a matlab data files used for the RadialBasis Neural Network example.
- testData_RecurrentNN.mat	It is a matlab data files used for the Recurrent Neural Network (Elman) example.
- testData_FeedForwardNN.mat	It is a matlab data files used for the FeedForward Neural Network example.
- NeuralNetwork.mo		The library
- readme.txt			This file.
