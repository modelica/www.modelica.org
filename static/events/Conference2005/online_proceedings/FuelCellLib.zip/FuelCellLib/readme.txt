
--------------INSTALLATION---------------------------------------------------

In order to open FuelCellLib library, select in the Dymola window 
File/Open and open the file package.mo. This file is located 
under directory /FuelCellLib.
-----------------------------------------------------------------------------

--------------HELP-----------------------------------------------------------

A more pleasant interface of help is shown in the library, to access to this,   
pick up the "info" on contextual menu of "FuelCellLib" in "Package Window"
-----------------------------------------------------------------------------

--------------COMMENTS and CONSIDERATIONS------------------------------------

Any comment or consideration about the library, send to e-mail:marubio@iai.csic.es
-----------------------------------------------------------------------------