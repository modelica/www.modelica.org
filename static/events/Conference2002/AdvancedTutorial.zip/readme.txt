This directory contains the following files:

- Slides of the "Advanced Tutorial" session and the slides
  for the exercises of this session
  (Modelica2002-AdvancecTutorial.pdf
   Modelica2002-AdvancedExercises.pdf)

- The utility file needed for exercise 1
  (SteamProperties.mo)

- The solutions of exercise 1
  (SolutionsExercise1.mo)

- The utility file needed for exercise 2
  (ServoLib1.mo)

- The solutions of exercise 2
  (SolutionsExercise2.mo)

