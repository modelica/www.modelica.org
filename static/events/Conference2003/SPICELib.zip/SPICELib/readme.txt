In order to open SPICELib library, select in the Dymola window 
File/Open and open the file package.mo. This file is located 
under directory /SPICELib.
The tutorial package contains examples showing how to run each 
type of analysis.
Inside /SPICELib/help folder you can find SPICELib.html, which 
is the main page to access the documentation.