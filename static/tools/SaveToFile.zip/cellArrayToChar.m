% ******************************************************************************
% * Author:   ARS
% * 
% * Description: Converts the cellarray to a matrix. Empty space in matrix
% *     is filled with Byte "0" not space!
% *
% * Parameter: cellMatrix := Matrix to be saved (must be 1 or 2 dimensional);
% *            
% * Return:    Matrix converted to uint8-matrix.
% * 
% * Example:   [celOutSignalNames, celPortDst, stcStatus] = ...
% *                     GenerateBusHierarchy(hInterfaceBlock,stcBusStruct,sbpLibModeBlock)
% *
% *****************************************************************************
function [Matrix] = cellArrayToChar(cellMatrix)

lMaxLength = size (char(cellMatrix),2);
lRows = size (cellMatrix,1);

Matrix = [];
for iRowCounter = 1:lRows
    s_RowValue = char(cellMatrix(iRowCounter));
    lRowLength = size (char(s_RowValue),2);
    Matrix = [Matrix ; [s_RowValue, zeros(1,lMaxLength-lRowLength)]];
end

Matrix = uint8 (Matrix);