% ******************************************************************************
% * Author:   ARS
% * 
% * Description: Function extract all fieldnames of a nested structure into a cell
% *              array.
% *
% * Parameter: srcBusSignal         := structure as it cames from
% *                                     get_param(hBlock,'BusStruct')
% *            varargin             := reserved for recusive function call
% * Return:    celSignalNameArray   := cell array with signal names
% * Errors:    
% * Example:   celSignalNameArray = BusStruct2SignalName(srcBusSignal)
% *
% ******************************************************************************
function celSignalNameArray = BusStruct2SignalName(srcBusSignal,varargin)

% set input values 
if nargin > 1
    celSignalNameArray = varargin{1};
    strParentName     = varargin{2};
else    
    celSignalNameArray = [];
    strParentName      = [];    
end

if ~isempty(srcBusSignal)
    nSignal = length(srcBusSignal);
    for iSignal = 1:nSignal
        
        % create fieldname of current level    
        if isempty(strParentName)
            strSignalName = srcBusSignal(iSignal).name;
        else
            strSignalName = [strParentName,'.',srcBusSignal(iSignal).name];
        end
        
        % create return value of current level or call recursive BusStruct2SignalName 
        if isempty(srcBusSignal(iSignal).signals)
            celSignalNameArray  = [celSignalNameArray;{strSignalName}];
        else
            celSignalNameArray = BusStruct2SignalName(srcBusSignal(iSignal).signals,...
                                                       celSignalNameArray,...
                                                       strSignalName);
        end        
    end
end