This directory contains an extension for Simulink supporting the Dymola-File format.

Dymola is a registrated trademark of dynamsim corporation.
Simulink is a registrated trademark of TheMathworks corporation.
Modelica is a unified object-oriented language for physical systems modeling 
(see http://www.Modelica.org).

Requirements
===============
Simulink R13sp1 or R14.
Dymola 5.3.

Installation
============
Just copy all files into your simulink search-path. The new simulink-block in the file
SaveToFile.mdl can be used anywhere in your simulink-models.

Using the block
================
The block can be connected to any simulink bus. The data of the bus is stored into a 
file. Also the signal names are stored into the file. There are no known file size limitations.
The file is in mat-4 file format and can be easily read with Dymola as a standard result-file.
Just open the file from the simulation-pane with the menu-command "Plot-Open Result".

Have fun!

Arne Schmenkel <arne.schmenkel@de.opel.com>
