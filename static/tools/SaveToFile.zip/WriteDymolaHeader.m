% ******************************************************************************
% * Author:   ARS
% * 
% * Description: Saving Header in Dymola/Matlab fileformat 
% *     for "To File"-Simulink-sink block.
% *     This is the old MAT 4 file format. That's why all Matlab 4
% *     restrictions apply.
% *     We save in "transponed" format. This means data can sucessivly
% *     added.
% *
% * Parameter: None.
% *            
% * Return:    celOutSignalNames :=  cell array with output signals
% *            celPortDst        :=  cell array with ports of output signals
% *            stcStatus         :=  status struct 
% * 
% * Example:   [celOutSignalNames, celPortDst, stcStatus] = ...
% *                     GenerateBusHierarchy(hInterfaceBlock,stcBusStruct,sbpLibModeBlock)
% *
% *****************************************************************************
function []=WriteDymolaHeader ()

% ATTENTION: This code can easily be but into an M-S-function!
% Doing this would also allow to write the data matrix.
% Then there would ne no need for the "ToFile"-matlab block.
% A FromFileWithHeader could also be done this way.

% Name of data-time signals.
Names = GetSignalNames (gcb,'in');

% Number of signals.
lPortNumber = size (Names,1);

% Open file header.
fid = fopen ('untitled_header.mat','w');

% Generate Dymola data-description matrix.
Aclass = cellstr('Atrajectory');
Aclass =[Aclass; cellstr('1.1')];
Aclass =[Aclass; cellstr(' ')];
% Following line: "binTrans" for transposed saving of all following
%                 "" for normal saving of all following matrixes.
Aclass =[Aclass; cellstr('binTrans')];
Aclass = cellArrayToChar (Aclass);
WriteMatrix(fid, Aclass, 'uint8', 51,'Aclass');

% Name Matrix- Contains all names of data.
Name = cellstr('Time');
Name = [Name; Names];
Name = cellArrayToChar (Name);
WriteMatrix(fid, Name', 'uint8',51, 'name');
    
    
% Description Matrix. Contaones description - same as name.
Description = cellstr('Time in [s]');
Description = [Description; Names];
Description = cellArrayToChar (Description);
WriteMatrix(fid, Description', 'uint8', 51,'description');    

% DataInfo. Encodes position and compression type of data.
% First Byte: 1,2: We always have no compression i.e. "2". Saved to data_2 matrix
% Second Byte: n: index(row/column) of data to "Name"-Matrix

% Build matrix.
aThisDataInfo = [2*ones(lPortNumber,1), [2:1:1+lPortNumber]', zeros(lPortNumber,1), -1*ones(lPortNumber,1)];
DataInfo = [0,1,0, -1];
DataInfo = [DataInfo; aThisDataInfo]; 
WriteMatrix(fid, DataInfo', 'int32',20, 'dataInfo');    

% Data_1. Matrix with compressed data. Not used yet.
data_1 = [];
WriteMatrix(fid, data_1, 'int32',0, 'data_1');    

% Close header file.
fclose (fid);

% Later the data will appeded as data_2 matrix (64-bit iEEE)
% Same format as original to-file Block.
%!copy /B untiled_header.mat + untitled1.mat tt.mat
