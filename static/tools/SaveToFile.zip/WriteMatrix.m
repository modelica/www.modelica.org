% ******************************************************************************
% * Author:   ARS
% * 
% * Description: Saves a matrix in given format to given file.
% *     Saving Header in Dymola/Matlab fileformat 
% *     for "To File"-Simulink-sink block.
% *     This is the old MAT 4 file format. That's why all Matlab 4
% *     restrictions apply.
% *
% * Parameter: Matrix := Matrix to be saved (must be 1 or 2 dimensional);
% *            Format := format string like : 
% *                 DOUBLE, DATATYPES, UINT8, UINT16, UINT32, UINT64, INT16, INT32, INT64.;
% *            fid := File ID opened with fopen (... 'w');
% *            Name := name of matrix. 
% *            T_Byte : The T_Byte of Matlab 4 format. Ususally 
% *                 0 full Matrix
% *                 1 Text Matrix
% *                 2 sparse Matrix
% *                 51 dymola Text Matrix 
% *                 20 dymola integer Matrix
% *                 0 dymola full Matrix
% *
% *            
% * Return:    celOutSignalNames :=  cell array with output signals
% *            celPortDst        :=  cell array with ports of output signals
% *            stcStatus         :=  status struct 
% * 
% * Example:   [celOutSignalNames, celPortDst, stcStatus] = ...
% *                     GenerateBusHierarchy(hInterfaceBlock,stcBusStruct,sbpLibModeBlock)
% *
% *****************************************************************************
function [stcStatus] = WriteMatrix(fid, ...
                           Matrix, ...
                           Format, ...
                           T_Byte, ...
                           Name)

ar_matrix = Matrix;
s_MatrixName = Name;

% See definition of Matlab 4 file in matlab definition.
CONST_MATFILE_M_BYTE = 0;
CONST_MATFILE_O_BYTE = 0;
CONST_MATFILE_P_BYTE = 0;
CONST_MATFILE_T_BYTE = T_Byte;
CONST_IMAG_F = 0;
lRows = size (ar_matrix,1);
lColumns = size (ar_matrix,2);
lNameLength = 1+size (s_MatrixName,2);
s_MatrixNameM = [(uint8 (s_MatrixName)), 0];

% Write MOPT-Bytes.
fwrite(fid,CONST_MATFILE_T_BYTE,'int8');
fwrite(fid,CONST_MATFILE_P_BYTE,'int8');
fwrite(fid,CONST_MATFILE_O_BYTE,'int8');
fwrite(fid,CONST_MATFILE_M_BYTE,'int8');

fwrite(fid,lRows,'int32');
fwrite(fid,lColumns,'int32');
fwrite(fid,CONST_IMAG_F,'int32');
fwrite(fid,lNameLength,'int32');

fwrite(fid,s_MatrixNameM,'uint8');
fwrite(fid,ar_matrix,Format);





