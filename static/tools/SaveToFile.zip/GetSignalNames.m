% ******************************************************************************
% * Author:   ARS
% * 
% * Description: Function GetSignalNames determines the 
% *            input signal names of a block.
% *
% * Parameter: varargin{1}  := sbpInterfaceBlock  or hInterfaceBlock 
% *
% *            sbpInterfaceBlock    := Simulink Block Path to the 
% *                                     BusConverter Block
% *
% *            hInterfaceBlock      := Handle to the BusConverter Block
% * 
% *            strMode              := 'in'  => returning input structure
% *                                    'out' => returning output structure      
% *            varargin{2}          := strMode
% *                                 := cell : a nested cell-array is
% *                                    returned.
% *                                 := sruct : the original nested bus
% *                                    structure is returned.
% *          
% *            if not specified 'in' is default value
% *          
% * Return:    varargout{1} 
% *            celPortArray      := Cell Array with signal names
% *            varargout{2}
% *            stcStatus         := Struct with status / error information
% *          
% * Errors:    stcStatus.isError        = 1;
% *            stcStatus.strStatusMsg  = 'Could not find system' 
% *
% * Example:   [celPortArray,stcStatus] = GetSignalNames(gcb,'in'), returns
% *            all inputs of the current block.
% *
% ******************************************************************************
function varargout = GetSignalNames(varargin)

% save current system and block handle 
hCurrentSystem = get_param(0,'CurrentSystem');
hCurrentBlock  = get_param(hCurrentSystem,'CurrentBlock');

% call intrinsic function
[PortArray,stcStatus] = GetBusStc(varargin{:});

% Restore current system and block handles. 
try
    set_param(0,'CurrentSystem',hCurrentSystem);
    set_param(hCurrentSystem,'CurrentBlock',hCurrentBlock);
end

% disp error if error struct is not requested from calling function
if  stcStatus.isError & nargout < 2
    disp(stcStatus.strStatusMsg)
end

% set output parameters
varargout{1} = PortArray;
if nargin > 1
     varargout{2} = stcStatus;
end

% ******************************************************************************
% * Author:   MO.
% * 
% * Description: Function GetBusStc determines the structure of the 
% *            input signal of the BusConverter Block.
% *
% * Parameter: varargin{1}  := sbpInterfaceBlock  or hInterfaceBlock 
% *
% *            sbpInterfaceBlock    := Simulink Block Path to the 
% *                                     BusConverter Block
% *
% *            hInterfaceBlock      := Handle to the BusConverter Block
% * 
% *            strMode              := 'in'  => returning input structure
% *                                    'out' => returning output structure      
% *            varargin{2}          := strMode
% *                                 := cell : a nested cell-array is
% *                                    returned.
% *                                 := sruct : the original nested bus
% *                                    structure is returned.
% *          
% *            if not specified 'in' is default value
% *
% * Return:    celPortArray      := Cell Array with signal names
% *            stcStatus         := Struct with status / error information
% *          
% * Errors:    stcStatus.isError        = 1;
% *            stcStatus.strStatusMsg  = 'Could not find system' 
% *
% * Example:   [celPortArray,stcStatus] = GetBusStruct(sbpInterfaceBlock,'in')
% *
% ******************************************************************************
function [celPortArray,stcStatus] = GetBusStc(varargin)

% init output arguments
celPortArray = [];
stcStatus.isError = 0;
stcStatus.strStatusMsg  = 'No Error';

% init function variables
srcBusSignal = [];
hInterfaceBlock = [];
sbpInterfaceBlock = [];
strMode = 'in';

% Check type and number of input arguments.
if nargin < 1
    hInterfaceBlock = gcbh;                 
else
    if ischar(varargin{1}) 
        if strcmp(lower(varargin{1}),'in') | strcmp(lower(varargin{1}),'out')
            hInterfaceBlock = gcbh;            
            strMode = lower(varargin{1});
        else
            % assuming simulink block path              
            sbpInterfaceBlock = varargin{1};
        end    
    elseif ishandle(varargin{1}) 
        % assuming simulink block handle, no error handling if other handle 
        hInterfaceBlock = varargin{1};
    else 
        % no valid input data type    
        stcStatus.isError = 1;
        stcStatus.strStatusMsg  = 'function GetSignalNames: wrong data type of input argument';
        return
    end        
end
if nargin > 1 && ischar(varargin{2}) && strcmp(lower(varargin{2}),'out')         
    strMode = 'out';
end   

if ischar(varargin{nargin}) && strcmp(lower(varargin{nargin}),'struct')  
    strModeOut = 'struct';
else
    strModeOut = 'cell';
end
        
% Inital assign values to empty data.
if isempty(sbpInterfaceBlock) & isempty(hInterfaceBlock)
    stcStatus.isError = 1;
    stcStatus.strStatusMsg  = 'function GetSignalNames: unexpected error';
    return    
elseif isempty(sbpInterfaceBlock)
    sbpInterfaceBlock = getfullname(hInterfaceBlock);             
elseif isempty(hInterfaceBlock)
    hInterfaceBlock = get_param(sbpInterfaceBlock,'Handle');
end

% Check if system handle / name is valid.
try 
    find_system(hInterfaceBlock);
catch
    stcStatus.isError = 1;    
    stcStatus.strStatusMsg  = 'Could not find system';
    return
end

sbpInterfaceParentSys = get_param(hInterfaceBlock,'parent');

% Get port handles of interface block. These are the in and out-simulink
% blocks.
hInterfacePort = get_param(sbpInterfaceBlock,'PortHandles');

% Get port handles depending on mode.
if strcmp(strMode,'out')
    hPort = hInterfacePort.Outport;
else
    hPort = hInterfacePort.Inport;
end

nPort = length(hPort);    

%loop over all ports
for iPort = 1:nPort
    
    hLinePort = get_param(hPort(iPort),'Line');
    % check connectivity
    if ~ishandle(hLinePort) | isempty(hLinePort)
        errordlg('BusConverter-block not properly connected.', 'Error in BusConverter');
        continue;
    end

    % Getting info about source and destination of inputs / outputs 
    % connected to the "BusConverte-Block".
    hPortSrc = get_param(hLinePort,'SrcPortHandle');
    hPortDst = get_param(hLinePort,'DstPortHandle');

    % Check following: Currently only one source-block and one destination
    % block is allowed!
    if (length(hPortSrc)>1 || length(hPortDst) > 1)    
        errordlg('Only one target and one source block allowed.', 'Error in BusConverter');
        continue;
    end

    
    % Check connectivity. The Block must be connected for this of course!
    if ~ishandle(hPortSrc) || isempty(hPortSrc) || ...
       ~ishandle(hPortDst) || isempty(hPortDst) 
        disp(['[Warning]: ',upper(strMode(1)),strMode(2:end),...
                'port no. ',num2str(iPort),...
                ' is not connected'])
        continue;
    end    
    
    intPortNumberSrc = get_param(hPortSrc,'PortNumber');
    intPortNumberDst = get_param(hPortDst,'PortNumber');
    
    strBlockSrc = get_param(get_param(hLinePort,'SrcBlockHandle'),'Name');
    strBlockDst = get_param(get_param(hLinePort,'DstBlockHandle'),'Name');
            
    % Add temporary busselctor-block to parent system of interface block.
    % With this block we can find out the connected bus structure. 
    sbpBusCreatorTmp = [sbpInterfaceParentSys,'/','strBusCreatorTmp'];

    hBusCreatorTmp  = add_block('Simulink/Signal Routing/Bus Creator',sbpBusCreatorTmp,'Inputs','1');
    hLineTmp         = add_line(sbpInterfaceParentSys,[strBlockSrc,'/',num2str(intPortNumberSrc)],'strBusCreatorTmp/1');
    
    % get structure of signals
    srcBusSignal = get_param(sbpBusCreatorTmp,'BusStruct');
    
    % Delete the temporary blocks and line.
    delete_line(sbpInterfaceParentSys,[strBlockSrc,'/',num2str(intPortNumberSrc)],'strBusCreatorTmp/1');
    delete_block(sbpBusCreatorTmp);

    % Extract signal names from bus structure.
    % Now recurivly find out structure of the bus.
    if ~isempty(srcBusSignal)
        if strcmp(strModeOut,'cell')
            celPortArray = [celPortArray;BusStruct2SignalName(srcBusSignal)];
        else
            celPortArray = srcBusSignal; 
        end
    end    
end