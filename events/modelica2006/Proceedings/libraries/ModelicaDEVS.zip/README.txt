This zip file contains three types of files: 


1. The ModelicaDEVS library
***************************

The ModelicaDEVS.mo library itself is usually put into the Dymola/work folder, or a subfolder 
of it.



2. Pictures
***********

The .png and .jpg files in the Images-folder are used for the documentation of the components 
and packages in the ModelicaDEVS library. The folder Images should be put into the same 
directory as the ModelicaDEVS.mo file.



3. C-function
*************

A .cpp file used for the external C-function declaration in the Delay block. This file has to
be put into the Dymola/Source folder.




