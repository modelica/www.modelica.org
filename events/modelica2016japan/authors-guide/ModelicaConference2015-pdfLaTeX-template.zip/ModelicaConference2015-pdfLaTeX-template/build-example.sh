#!/bin/sh

pdflatex example-paper
bibtex example-paper
pdflatex example-paper
pdflatex example-paper
