This tutorial
 
   Modelica and Dymola for System Design

requires Dymola 6 Beta 1, i.e., a Beta Version of the
next major release of Dymola. Please, contact Dynasim
(info@dynasim.se) for this version and for the 
exercise material. Most likely, newer versions of Dymola
and of the exercise material will be available when you
contact Dynasim.
