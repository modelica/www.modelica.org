Modelica'2005 Libraries and Tutorials
=====================================

This pacakge contains the turorials held at the 
Modelica 2005 Conference in Hamburg.

You will find a pdf file in each tutorial subdirectory containing
the tutorial slides.

If you are using Dymola, 

 - start Dymola
 - switch to simulation mode (Window/Mode/Simulation).
 - run the setup script (Simulation/Run Script). Select the appropriate
   setup script (Modelica2005\Tutorials\xxx\setup.mos) 
   (available for Vehicle Systems and Thermo Tutorial). 
 - select a command from the "Commands" menu or open a model in the 
   package browser, or what is suggested by your instructor.
