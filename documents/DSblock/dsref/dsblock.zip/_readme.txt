This directory contains files which are referenced
in the "dsblock.htm" document.

  circuit.cpp    Example: Electrical circuit as DSblock demonstrating 
                 hierarchical modelling.
  circuit.mo     The Modelica model for circuit.cpp
  dsblock.cpp    The sources of the DSblock interface.
  dsblock.h      Header file of DSblock to integrator.
  dsdymo.cpp     Source of interface to old DSblock interface version 3.3
  dsdymo.h       Header file for dsdymo.cpp.
  dsmodel.h      Header file of DSblock to implement Modelica models.
  hybrid.cpp     Example: Hybrid model as DSblock demonstrating hybrid
                 modelling features of DSblock.
  hybrid.dym.mo  The Modelica model for hybrid.cpp which has been
                 simulated with the Dymola Modelica compiler 
                 (since this is a beta release, some Modelica features
                 are not yet implemented and Dymola syntax is used instead).
  hybrid.mo      The Modelica model for hybrid.cpp.
  main.cpp       Main program to show how a DSblock is called and to print
                 model information.

All programms have been tested on a PC with Visual C++, version 4.

Jan 11, 1998. Martin Otter

