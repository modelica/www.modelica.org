#ifndef DSDYMO_H
#define DSDYMO_H

#ifdef __cplusplus
extern "C" {
#endif

typedef long   integer;
typedef long   logical;
typedef double doublereal;

extern void terminating_(integer *icall);


/* Initialization of DSblock */
extern
int dsblockb_(integer*    iopt , integer*    info , integer*    sig,
              integer*    dim  , doublereal* t0   , doublereal* x0,
              doublereal* xd0  , doublereal* dp   , integer*    ip,
              logical*    lp   , doublereal* duser, integer*    iuser,
              logical*    luser, integer*    ierr);


/* Initial computations. */
extern
int dsblocks_(doublereal* t0    , doublereal* x0    , doublereal* xd0, 
              doublereal* u0    , doublereal* dp    , integer*    ip ,
              logical*    lp    , doublereal* tevent, integer*    hcross,
              integer*    dimnew, doublereal* duser , integer*    iuser,
              logical*    luser , integer*    ierr);


/* Compute right hand side. */
extern
int dsblockf_(integer    *icall, doublereal *time , doublereal *x,
              doublereal *xd   , doublereal *u    , doublereal *dp,
              integer    *ip   , logical    *lp   , doublereal *f,
              doublereal *duser, integer    *iuser, logical    *luser,
              integer    *ierr) ;



/* Compute output signals. */
extern
int dsblockg_(integer    *icall, doublereal *time , doublereal *x,
              doublereal *xd   , doublereal *u    , doublereal *dp,
              integer    *ip   , logical    *lp   , doublereal *y,
              doublereal *duser, integer    *iuser, logical    *luser,
              integer    *ierr) ;


/* Compute indicator signals. */
extern
int dsblockh_(integer    *icall, doublereal *time , doublereal *x,
              doublereal *xd   , doublereal *u    , doublereal *dp,
              integer    *ip   , logical    *lp   , doublereal *z,
              doublereal *duser, integer    *iuser, logical    *luser,
              integer    *ierr) ;


/* Compute auxiliary signals. */
extern
int dsblockk_(integer    *icall, doublereal *time , doublereal *x,
              doublereal *xd   , doublereal *u    , doublereal *dp,
              integer    *ip   , logical    *lp   , doublereal *w,
              doublereal *duser, integer    *iuser, logical    *luser,
              integer    *ierr) ;


/* Event handling. */
extern
int dsblockv_(integer    *icall , integer    *iopt  , doublereal *time ,
              doublereal *x     , doublereal *xd    , doublereal *u    ,
              doublereal *dp    , integer    *ip    , logical    *lp   ,
              doublereal *z     , integer    *hinfo , doublereal *tevent,
              integer    *hcross, integer    *dimnew, integer    *iprior,
              doublereal *duser , integer    *iuser , logical    *luser,
              integer    *info) ;


/*  Called after integration terminated */
extern
int dsblockt_(integer    *iopt , doublereal *time , doublereal *x,
              doublereal *xd   , doublereal *u    , doublereal *dp,
              integer    *ip   , logical    *lp   , doublereal *duser,
              integer    *iuser, logical    *luser, integer    *ierr);


/* Close DSblock model */
extern
int dsblockc_(integer *iopt , doublereal *duser, integer *iuser, 
              logical *luser, integer    *ierr);


/* Compute Jacobian matrix (no implementation) */
extern
int dsblockj_(integer    *icall, doublereal *time , doublereal *x,
              doublereal *xd   , doublereal *u    , doublereal *dp,
              integer    *ip   , logical    *lp   , doublereal *cj, 
              doublereal *jac  , integer    *njac , doublereal *duser,
              integer    *iuser, logical    *luser, integer    *ierr);


/*  Check parameters (no implementation) */
extern
int dsblockp_(doublereal *dp   , integer    *ip   , logical    *lp,
              integer    *ityp , integer    *ipt  , integer    *ipos,
              integer    *ndim , integer    *dim  , doublereal *x,
              doublereal *xd   , doublereal *duser, integer    *iuser,
              logical    *luser, integer    *ierr);


#ifdef __cplusplus
}
#endif

#endif
