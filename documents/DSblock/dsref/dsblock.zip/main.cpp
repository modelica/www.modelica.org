
// #include <iostream>

#include "dsblock.h"
using namespace dsblock;

  
int main () {
   HybridDAE  dae;
   double x [] = { 3.0,  6.0,  9.0};
   double *xd = 0;
   double *wi = 0;
   double *u  = 0;

   dae.printModel();
   dae.printModelDimensions();

   dae.setArg(x, xd, wi, u, 0.0);
   dae.printModelInterface();

   return 0;

}

