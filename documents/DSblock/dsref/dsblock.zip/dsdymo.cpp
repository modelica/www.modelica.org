/* dsblock.f -- translated by f2c (version 19940127). */

#include "dsdymo.h"
#include "dsblock.h"
using namespace dsblock;

extern "C" {
   extern int  blo3pd_ (char*, char*, long, long);
   extern int  blo3sx_ (char*, char*, long, long);
   extern int  blo3sd_ (char*, char*, long, long);
   extern int  blo3su_ (char*, char*, long, long);
   extern int  blo3sw_ (char*, char*, long, long);
   extern int  blo3sy_ (char*, char*, long, long); 
   extern int  blo3tz_ (char*, char*, integer*, integer*, long, long);
   extern int  blosii_ (integer*, integer*, integer*);
   extern int  atoutputpoint_(double*);
}


static HybridODE  ode;
static HybridDAE& dae = (HybridDAE& ) ode;

static void dsblockNames(FullDynamicSystem& sys, ModelicaClass& component,
                         double x0[], int& ix0, double dp[], int& idp);

static void dsblockAux(DynamicSystem& sys, ModelicaClass& component, 
                       double w[], int& iw);

static double lastDefinedTimeEvent = -1.e30;



int dsblockb_(integer*    iopt , integer*    info , integer*    sig,
              integer*    dim  , doublereal* t0   , doublereal* x0,
              doublereal* xd0  , doublereal* dp   , integer*    ip,
              logical*    lp   , doublereal* duser, integer*    iuser,
              logical*    luser, integer*    ierr) {
  /* Initialization of DSblock */
     if (*iopt == 1) {

     } else if (*iopt == 2) {
        /* Type of equation */
           *info = 0;   // 0/1 ODE/DAE

        /* Provide model dimensions */
           sig[0] = ode.nxMax();
           sig[1] = ode.nu();
           sig[2] = ode.ny();
           sig[3] = (ode.nzMax() > 0 ? 1 : 0);
           sig[4] = dae.nwMax_e() + ode.nb() + ode.nbnew();  // nw
           sig[5] = ode.np_r();   // number of parameters
  
           dim[0] = ode.nxMax();
           dim[1] = ode.nu();
           dim[2] = ode.ny();
           dim[3] = ode.nzMax();
           dim[4] = sig[4];      // nw
           dim[5] = ode.np_r();
           dim[6] = 0;           // number of integer parameters
           dim[7] = 0;           // number of logical parameters

      } else if (*iopt == 3) { 
        /* Define signal names and initial values */
           int ix0 = 0;
           int idp = 0;

           Model& model = ode.getModel();
           ode.clearBuffer();

           dsblockNames(ode, *model.child(), x0, ix0, dp, idp);

           if ( ode.nzMax() > 0 ) {
              long  dim1 = 1;
              long  nz   = ode.nzMax();
              char* name = "z";
              char* desc = "Crossing signals";
              blo3tz_(name, desc, &dim1, &nz, strlen(name), strlen(desc));
           }
      }

    *ierr = 0;
    return 0;
}



int dsblocks_(doublereal* t0    , doublereal* x0    , doublereal* xd0, 
              doublereal* u0    , doublereal* dp    , integer*    ip ,
              logical*    lp    , doublereal* tevent, integer*    hcross,
              integer*    dimnew, doublereal* duser , integer*    iuser,
              logical*    luser , integer*    ierr) {
  /* Initial computations. */

  /* Inquire simulation run time parameters */
     long i = 2;
     long prior; 
     long ierror;
     blosii_(&i, &prior, &ierror);
     if ( ierror == 0  ) {
        if ( prior > 0 ) {
           ode.debug(True);
           ode.printPriority(prior);
        } else {
           ode.debug(False);
        }
     }

  /* Set input arguments and perform initial event */
     ode.setArg(x0, u0, *t0);
     ode.performInitial();

  /* Return output arguments */
     ode.getArg(x0);
     dimnew[0] = ode.nx();
     dimnew[1] = ode.nz();
     *tevent   = ode.nextTimeEvent();
     lastDefinedTimeEvent = *tevent;

     for (i=0; i<ode.nzMax()/2; i++) {
        hcross[2*i  ] = -1;
        hcross[2*i+1] = +1;
     }

     return 0;
}



int dsblockf_(integer    *icall, doublereal *time , doublereal *x,
              doublereal *xd   , doublereal *u    , doublereal *dp,
              integer    *ip   , logical    *lp   , doublereal *f,
              doublereal *duser, integer    *iuser, logical    *luser,
              integer    *ierr) {
  /* Compute right hand side. */
     if ( *icall == 0 ) {
        *icall = 1;
        ode.setArg(x, u, *time);
     }
     ode.derivatives(f);
     return 0;
}



int dsblockg_(integer    *icall, doublereal *time , doublereal *x,
              doublereal *xd   , doublereal *u    , doublereal *dp,
              integer    *ip   , logical    *lp   , doublereal *y,
              doublereal *duser, integer    *iuser, logical    *luser,
              integer    *ierr) {
  /* Compute output signals. */
     if ( *icall == 0 ) {
        *icall = 1;
        ode.setArg(x, u, *time);
     }
     ode.outputs(y);
     return 0;
}



int dsblockh_(integer    *icall, doublereal *time , doublereal *x,
              doublereal *xd   , doublereal *u    , doublereal *dp,
              integer    *ip   , logical    *lp   , doublereal *z,
              doublereal *duser, integer    *iuser, logical    *luser,
              integer    *ierr){
  /* Compute indicator signals. */
     if ( *icall == 0 ) {
        *icall = 1;
        ode.setArg(x, u, *time);
     }
     ode.crossings(z);
     return 0;
}



int dsblockk_(integer    *icall, doublereal *time , doublereal *x,
              doublereal *xd   , doublereal *u    , doublereal *dp,
              integer    *ip   , logical    *lp   , doublereal *w,
              doublereal *duser, integer    *iuser, logical    *luser,
              integer    *ierr){
  /* Compute auxiliary signals. */
    if ( icall[1] == 1 ) {
       /* Auxiliary signals will be stored */
          if ( *icall == 0 ) {
             *icall = 1;
             ode.setArg(x, u, *time);
          }
           int iw = 0;
           ode.clearBuffer();
           dsblockAux(ode, ode.getModel(), w, iw);
    }
    *ierr = atoutputpoint_(time);
    
    return 0;
}



int dsblockv_(integer    *icall , integer    *iopt  , doublereal *time ,
              doublereal *x     , doublereal *xd    , doublereal *u    ,
              doublereal *dp    , integer    *ip    , logical    *lp   ,
              doublereal *z     , integer    *hinfo , doublereal *tevent,
              integer    *hcross, integer    *dimnew, integer    *iprior,
              doublereal *duser , integer    *iuser , logical    *luser,
              integer    *info){
  /* Event handling. */
     if ( *icall == 0 ) {
        *icall = 1;
        ode.setArg(x, u, *time);
     }
     ode.performEvent();

  /* Return arguments */
     ode.getArg(x);
     dimnew[0] = ode.nx();
     dimnew[1] = ode.nz();
     if ( iopt[0]!=0 && (ode.nextTimeEvent() > lastDefinedTimeEvent) ) {
        *tevent = ode.nextTimeEvent();
        lastDefinedTimeEvent = *tevent;
     }
     *info = 1;
     return 0;
}



int dsblockt_(integer    *iopt , doublereal *time , doublereal *x,
              doublereal *xd   , doublereal *u    , doublereal *dp,
              integer    *ip   , logical    *lp   , doublereal *duser,
              integer    *iuser, logical    *luser, integer    *ierr){
  /* Called after integration terminated */

  /* iopt = 0: An error occured. blockB may not yet been called.
          = 1: Simulation terminated successfully
          = 2: Simulation terminated before reaching final time.
               (maybe due to an error, maybe because the model
               stopped the simulation)
  */
     ode.setArg(x, u, *time);
     ode.performTerminal();
     return 0;
}



int dsblockc_(integer *iopt , doublereal *duser, integer *iuser, 
              logical *luser, integer    *ierr) {
  /* Close DSblock model */

  /* not yet implemented */
     return 0;
}



int dsblockj_(integer    *icall, doublereal *time , doublereal *x,
              doublereal *xd   , doublereal *u    , doublereal *dp,
              integer    *ip   , logical    *lp   , doublereal *cj, 
              doublereal *jac  , integer    *njac , doublereal *duser,
              integer    *iuser, logical    *luser, integer    *ierr){
  /* Compute Jacobian matrix (no implementation) */
     return 0;
}



int dsblockp_(doublereal *dp   , integer    *ip   , logical    *lp,
              integer    *ityp , integer    *ipt  , integer    *ipos,
              integer    *ndim , integer    *dim  , doublereal *x,
              doublereal *xd   , doublereal *duser, integer    *iuser,
              logical    *luser, integer    *ierr) {
  /* Check parameters (no implementation) */
     return 0;
}



static void dsblockNames(FullDynamicSystem& sys, ModelicaClass& component,
                         double x0[], int& ix0, double dp[], int& idp) {

     // Traverse model and provide variable names and initial values
        int   lstr;
        char* str;

     // Store instance name in buffer
        sys.push(component.name());

     // Action according to type of class
        if ( component.classType() == RealClass ) {
           Real& rc     = (Real& ) component;
           Real& der_rc = rc.propertyRef();

           switch ( rc.property() ) {
             case State: // Define state
                            str  = sys.fullName();
                            lstr = sys.lenFullName();
                            blo3sx_(str, str, lstr, lstr);
                            x0[ix0] = rc.start();
                            ix0++;

                         // Define corresponding derivative of state
                            str  = sys.fullName(der_rc);
                            lstr = strlen(str);
                            blo3sd_(str, str, lstr, lstr);
                            break;

             case ExpliciteAlgebraic:
                            str  = sys.fullName();
                            lstr = sys.lenFullName();
                            blo3sw_(str, str, lstr, lstr);

             case Known: // Define Input and Parameter variables
                            if ( rc.interface() == Input ) {
                               str  = sys.fullName(); 
                               lstr = sys.lenFullName();
                               blo3su_(str, str, lstr, lstr);

                            } else if ( rc.variability() == Parameter ) {
                               str  = sys.fullName();
                               lstr = sys.lenFullName();
                               blo3pd_(str, str, lstr, lstr);
                               dp[idp] = rc.start();
                               idp++;
                            }
                            break;
           }

           // Define Output variables
              if ( rc.interface() == Output ) {
                 str  = sys.fullName();
                 lstr = sys.lenFullName();
                 blo3sy_(str, str, lstr, lstr);
              }

        } else if ( component.classType() == BooleanClass ) {
           str  = sys.fullName();
           lstr = sys.lenFullName();
           blo3sw_(str, str, lstr, lstr);
        }


     // Traverse sub-components (childs)
        if ( component.child() != 0 )
           dsblockNames(sys, *component.child(), x0, ix0, dp, idp);

     // Traverse next components
        sys.pop();  // pop component name from buffer
        if ( component.next() != 0 )
           dsblockNames(sys, *component.next(), x0, ix0, dp, idp);
   }



static void dsblockAux(DynamicSystem& sys, ModelicaClass& component, 
                       double w[], int& iw) {

     // Traverse model and store auxiliary variables in w

     // Action according to type of class
        if ( component.classType() == RealClass ) {
           Real& rc = (Real& ) component;

           if ( rc.property() == ExpliciteAlgebraic ) {
              w[iw] = rc._;
              ++iw;
           }

        } else if ( component.classType() == BooleanClass ) {
           Boolean& bc = (Boolean& ) component;

           if ( bc.property() == DiscreteState ||
                bc.property() == New ) {
              w[iw] = bc._ ? 1.0 : 0.0;
              ++iw;
           }
        }

     // Traverse sub-components (childs)
        if ( component.child() != 0 ) 
           dsblockAux(sys, *component.child(), w, iw);

     // Traverse next components
        if ( component.next() != 0 )
           dsblockAux(sys, *component.next(), w, iw);
   }
